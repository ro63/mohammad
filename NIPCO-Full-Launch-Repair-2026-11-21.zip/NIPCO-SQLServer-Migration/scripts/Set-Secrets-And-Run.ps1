﻿param(
 [Parameter(Mandatory=$true)][string]$AdminUsername,
 [Parameter(Mandatory=$true)][SecureString]$AdminPassword,
 [Parameter(Mandatory=$true)][SecureString]$JwtSigningKey
)
$ErrorActionPreference='Stop'
function ConvertTo-Plain([SecureString]$s) { $p=[Runtime.InteropServices.Marshal]::SecureStringToBSTR($s); try {[Runtime.InteropServices.Marshal]::PtrToStringBSTR($p)} finally {[Runtime.InteropServices.Marshal]::ZeroFreeBSTR($p)} }
$env:Bootstrap__AdminUsername=$AdminUsername
$env:Bootstrap__AdminPassword=ConvertTo-Plain $AdminPassword
$env:Jwt__SigningKey=ConvertTo-Plain $JwtSigningKey
if ([Text.Encoding]::UTF8.GetByteCount($env:Jwt__SigningKey) -lt 32) { throw 'JWT signing key must be at least 32 UTF-8 bytes.' }
$api=Join-Path $PSScriptRoot '..\src\Nipco.Api'
Push-Location $api
try {
 if (-not (Get-Command dotnet-ef -ErrorAction SilentlyContinue)) { dotnet tool install --global dotnet-ef --version 10.0.15 } else { dotnet tool update --global dotnet-ef --version 10.0.15 }
 dotnet restore
 dotnet ef migrations add InitialSqlServerSchema --project ..\Nipco.Infrastructure\Nipco.Infrastructure.csproj --startup-project .\Nipco.Api.csproj --output-dir Persistence\Migrations
 dotnet ef database update --project ..\Nipco.Infrastructure\Nipco.Infrastructure.csproj --startup-project .\Nipco.Api.csproj
 dotnet run
} finally { Pop-Location; Remove-Item Env:Bootstrap__AdminPassword -ErrorAction SilentlyContinue; Remove-Item Env:Jwt__SigningKey -ErrorAction SilentlyContinue }

﻿[CmdletBinding()]
param(
    [string]$SqlInstance = '',
    [int]$HttpsPort = 7241
)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$Root = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$ApiDir = Join-Path $Root 'src\Nipco.Api'
$FrontDir = Join-Path $Root 'frontend'
$FrontDist = Join-Path $FrontDir 'dist'
$WebRoot = Join-Path $ApiDir 'wwwroot'
$Solution = Join-Path $Root 'NIPCO.sln'
$ReleaseDll = Join-Path $ApiDir 'bin\Release\net10.0\Nipco.Api.dll'
$LogDir = Join-Path $env:ProgramData 'NIPCO\Logs'
$SecretDir = Join-Path $env:LOCALAPPDATA 'NIPCO'
$SecretFile = Join-Path $SecretDir 'jwt-key.dpapi'
$TranscriptStarted = $false
$jwtKey = $null
$secure = $null

function Convert-SecureToPlain([Security.SecureString]$Value) {
    $ptr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($Value)
    try { return [Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr) }
    finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr) }
}

function New-AndSaveJwtKey([string]$Path) {
    $bytes = New-Object byte[] 64
    $rng = [Security.Cryptography.RandomNumberGenerator]::Create()
    try { $rng.GetBytes($bytes) }
    finally { $rng.Dispose() }

    $plainKey = [Convert]::ToBase64String($bytes)
    $secureKey = ConvertTo-SecureString -String $plainKey -AsPlainText -Force
    try { $protectedKey = ConvertFrom-SecureString -SecureString $secureKey }
    finally { $secureKey.Dispose() }

    $parent = Split-Path -Parent $Path
    New-Item -ItemType Directory -Path $parent -Force | Out-Null
    $tempPath = "$Path.tmp"
    [System.IO.File]::WriteAllText($tempPath, $protectedKey, [System.Text.Encoding]::ASCII)
    Move-Item -LiteralPath $tempPath -Destination $Path -Force
    return $plainKey
}

try {
    if (-not (Test-Path $ApiDir)) { throw "پوشه API پیدا نشد: $ApiDir" }
    if (-not (Get-Command dotnet -ErrorAction SilentlyContinue)) { throw '.NET 10 Runtime/SDK یا دستور dotnet پیدا نشد.' }

    New-Item -ItemType Directory -Path $LogDir -Force | Out-Null
    New-Item -ItemType Directory -Path $SecretDir -Force | Out-Null
    $LogFile = Join-Path $LogDir ("Start-{0}.log" -f (Get-Date -Format 'yyyyMMdd-HHmmss'))
    Start-Transcript -Path $LogFile -Force | Out-Null
    $TranscriptStarted = $true

    if ([string]::IsNullOrWhiteSpace($SqlInstance)) {
        $instanceFile = Join-Path $env:ProgramData 'NIPCO\Config\sql-instance.txt'
        if (Test-Path $instanceFile) {
            $SqlInstance = [System.IO.File]::ReadAllText($instanceFile).Trim()
        }
        if ([string]::IsNullOrWhiteSpace($SqlInstance)) { $SqlInstance = 'localhost' }
    }

    # Read the DPAPI-protected JWT value using the current Windows user profile.
    # If the file is missing/corrupt or belongs to another Windows profile,
    # create a fresh key only; do not touch the SQL database or admin account.
    if (Test-Path $SecretFile) {
        try {
            $protected = [System.IO.File]::ReadAllText($SecretFile).Trim()
            if ([string]::IsNullOrWhiteSpace($protected)) { throw 'فایل کلید امنیتی خالی است.' }
            $secure = ConvertTo-SecureString -String $protected -ErrorAction Stop
            $jwtKey = Convert-SecureToPlain $secure
            if ([string]::IsNullOrWhiteSpace($jwtKey) -or [System.Text.Encoding]::UTF8.GetByteCount($jwtKey) -lt 32) {
                throw 'کلید بازیابی‌شده معتبر نیست.'
            }
        }
        catch {
            Write-Warning 'کلید JWT ذخیره‌شده قابل بازیابی نیست؛ کلید جدید مخصوص حساب Windows فعلی ساخته می‌شود. دیتابیس و حساب مدیر تغییر نمی‌کنند و کاربران باید دوباره وارد شوند.'
            $jwtKey = New-AndSaveJwtKey -Path $SecretFile
        }
        finally {
            if ($secure) { $secure.Dispose(); $secure = $null }
        }
    }
    else {
        Write-Warning 'فایل کلید JWT موجود نیست؛ کلید جدید مخصوص حساب Windows فعلی ساخته می‌شود. دیتابیس و حساب مدیر تغییر نمی‌کنند.'
        $jwtKey = New-AndSaveJwtKey -Path $SecretFile
    }

    # Reuse the previously successful frontend build when available. If the
    # dist folder is missing, rebuild it, then always publish it to API wwwroot.
    if (-not (Test-Path (Join-Path $FrontDist 'index.html'))) {
        if (-not (Test-Path $FrontDir)) { throw "پوشه Frontend پیدا نشد: $FrontDir" }
        if (-not (Get-Command npm -ErrorAction SilentlyContinue)) { throw 'npm پیدا نشد؛ Node.js را نصب کنید.' }
        Write-Host '[1/3] خروجی Frontend موجود نیست؛ ساخت رابط کاربری...' -ForegroundColor Cyan
        Push-Location $FrontDir
        try {
            npm install --no-audit --no-fund --no-progress
            if ($LASTEXITCODE -ne 0) { throw 'npm install ناموفق بود.' }
            npm run build
            if ($LASTEXITCODE -ne 0) { throw 'ساخت React/Vite ناموفق بود.' }
        }
        finally { Pop-Location }
    }

    if (-not (Test-Path (Join-Path $FrontDist 'index.html'))) {
        throw "خروجی رابط کاربری ساخته نشده است: $(Join-Path $FrontDist 'index.html')"
    }
    New-Item -ItemType Directory -Path $WebRoot -Force | Out-Null
    Copy-Item -Path (Join-Path $FrontDist '*') -Destination $WebRoot -Recurse -Force
    if (-not (Test-Path (Join-Path $WebRoot 'index.html'))) {
        throw "کپی رابط کاربری به مسیر API ناموفق بود: $WebRoot"
    }
    Write-Host "رابط کاربری آماده شد: $WebRoot\index.html" -ForegroundColor Green

    # Build Release only if the installed API binary is missing.
    if (-not (Test-Path $ReleaseDll)) {
        Write-Host '[2/3] فایل Release وجود ندارد؛ ساخت Backend...' -ForegroundColor Cyan
        Push-Location $Root
        try {
            dotnet restore $Solution
            if ($LASTEXITCODE -ne 0) { throw 'dotnet restore ناموفق بود.' }
            dotnet build $Solution -c Release --no-restore
            if ($LASTEXITCODE -ne 0) { throw 'ساخت Release دات‌نت ناموفق بود.' }
        }
        finally { Pop-Location }
    }
    if (-not (Test-Path $ReleaseDll)) { throw "فایل API پیدا نشد: $ReleaseDll" }

    $env:Jwt__SigningKey = $jwtKey
    $env:ASPNETCORE_ENVIRONMENT = 'Production'
    $env:ConnectionStrings__Maintenance = "Server=$SqlInstance;Database=NIPCO_DailyInspection;Trusted_Connection=True;Encrypt=True;TrustServerCertificate=True;MultipleActiveResultSets=True;Connect Timeout=30"

    Write-Host '[3/3] اجرای API از مسیر صحیح میزبان...' -ForegroundColor Cyan
    Write-Host "SQL Server: $SqlInstance"
    Write-Host "Web root: $WebRoot"
    Write-Host "آدرس محلی: https://localhost:$HttpsPort" -ForegroundColor Green
    Write-Host 'برای توقف سرور Ctrl+C را بزنید.' -ForegroundColor Yellow

    # ASP.NET Core resolves its content root from the current directory.
    # Running from ApiDir ensures wwwroot is src\Nipco.Api\wwwroot.
    Push-Location $ApiDir
    try {
        dotnet '.\bin\Release\net10.0\Nipco.Api.dll' --urls "https://localhost:$HttpsPort"
        if ($LASTEXITCODE -ne 0) { throw "API با کد خروج $LASTEXITCODE متوقف شد." }
    }
    finally { Pop-Location }
}
catch {
    Write-Host "خطا در اجرای NIPCO: $($_.Exception.Message)" -ForegroundColor Red
    if ($LogFile) { Write-Host "گزارش اجرا: $LogFile" -ForegroundColor Yellow }
    throw
}
finally {
    Remove-Item Env:Jwt__SigningKey -ErrorAction SilentlyContinue
    Remove-Item Env:ConnectionStrings__Maintenance -ErrorAction SilentlyContinue
    Remove-Item Env:ASPNETCORE_ENVIRONMENT -ErrorAction SilentlyContinue
    $jwtKey = $null
    if ($secure) { $secure.Dispose() }
    if ($TranscriptStarted) { Stop-Transcript | Out-Null }
}

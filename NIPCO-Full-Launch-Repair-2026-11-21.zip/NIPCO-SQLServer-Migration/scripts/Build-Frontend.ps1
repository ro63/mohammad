﻿$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$front = Join-Path $root 'frontend'
$www = Join-Path $root 'src\Nipco.Api\wwwroot'
if (-not (Get-Command node -ErrorAction SilentlyContinue)) { throw 'Node.js 22 LTS یا جدیدتر نصب نیست.' }
Push-Location $front
try { npm install --no-audit --no-fund --no-progress; if ($LASTEXITCODE -ne 0) { throw 'npm install ناموفق بود؛ دسترسی npm registry و وابستگی‌های Tailwind CSS را بررسی کنید.' }; npm run build; if ($LASTEXITCODE -ne 0) { throw 'ساخت React ناموفق بود.' } }
finally { Pop-Location }
if (Test-Path $www) { Remove-Item $www -Recurse -Force }
New-Item -ItemType Directory -Path $www | Out-Null
Copy-Item (Join-Path $front 'dist\*') $www -Recurse -Force
Write-Host 'React build copied to ASP.NET Core wwwroot.' -ForegroundColor Green

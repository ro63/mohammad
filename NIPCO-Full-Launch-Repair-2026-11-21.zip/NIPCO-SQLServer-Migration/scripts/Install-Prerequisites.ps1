﻿# Run in elevated PowerShell on the Windows application/database server.
$ErrorActionPreference = 'Stop'
Write-Host 'NIPCO prerequisite check' -ForegroundColor Cyan
if (Get-Command dotnet -ErrorAction SilentlyContinue) { dotnet --list-sdks } else { Write-Warning '.NET 10 SDK is not installed.' }
if (Get-Command node -ErrorAction SilentlyContinue) { node --version } else { Write-Warning 'Node.js 22 LTS or newer is not installed.' }

$sqlServices = @(Get-Service -ErrorAction SilentlyContinue | Where-Object { $_.Name -eq 'MSSQLSERVER' -or $_.Name -like 'MSSQL$*' })
if ($sqlServices.Count -eq 0) {
    Write-Warning 'No local SQL Server Database Engine service was found. Install SQL Server Database Engine first.'
} else {
    Write-Host 'Detected local SQL Server instances:' -ForegroundColor Green
    foreach ($svc in $sqlServices) {
        $instance = if ($svc.Name -eq 'MSSQLSERVER') { 'localhost (Default Instance)' } else { 'localhost\' + $svc.Name.Substring(6) }
        Write-Host ("  {0,-34} Service={1} Status={2}" -f $instance, $svc.Name, $svc.Status)
    }
}
Write-Host 'Recommended app connection for a default instance: -SqlInstance localhost'
Write-Host 'Recommended app connection for a named instance:   -SqlInstance localhost\INSTANCE_NAME'
Write-Host 'This check does not modify or delete any database.' -ForegroundColor Green

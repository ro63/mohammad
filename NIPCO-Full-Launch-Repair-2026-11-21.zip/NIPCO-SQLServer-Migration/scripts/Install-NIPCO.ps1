﻿[CmdletBinding()]
param(
    [string]$SqlInstance = 'localhost',
    [int]$HttpsPort = 7241
)
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$Root = Split-Path -Parent $PSScriptRoot
$ApiDir = Join-Path $Root 'src\Nipco.Api'
$InfraProject = Join-Path $Root 'src\Nipco.Infrastructure\Nipco.Infrastructure.csproj'
$FrontDir = Join-Path $Root 'frontend'
$LogDir = Join-Path $env:ProgramData 'NIPCO\Logs'
$ConfigDir = Join-Path $env:ProgramData 'NIPCO\Config'
$SecretDir = Join-Path $env:LOCALAPPDATA 'NIPCO'
New-Item -ItemType Directory -Path $LogDir -Force | Out-Null
New-Item -ItemType Directory -Path $ConfigDir -Force | Out-Null
New-Item -ItemType Directory -Path $SecretDir -Force | Out-Null
$LogFile = Join-Path $LogDir ("Install-{0}.log" -f (Get-Date -Format 'yyyyMMdd-HHmmss'))
Start-Transcript -Path $LogFile -Force | Out-Null

function Assert-Command([string]$Name, [string]$InstallHint) {
    if (-not (Get-Command $Name -ErrorAction SilentlyContinue)) { throw "$Name یافت نشد. $InstallHint" }
}
function Convert-SecureToPlain([Security.SecureString]$Value) {
    $ptr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($Value)
    try { [Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr) }
    finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr) }
}

try {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) { throw 'PowerShell را با گزینه Run as administrator اجرا کنید.' }
    Write-Host '=== نصب تمیز NIPCO Daily Inspection ===' -ForegroundColor Cyan
    Write-Host "مسیر پروژه: $Root"
    Write-Host "گزارش نصب: $LogFile"
    Write-Host 'هیچ پوشه، دیتابیس یا Docker volume موجودی حذف نمی‌شود.' -ForegroundColor Yellow

    Assert-Command 'dotnet' 'بسته .NET 10 SDK x64 را نصب کنید و PowerShell را دوباره باز کنید.'
    Assert-Command 'node' 'نسخه Node.js 22 LTS یا جدیدتر را نصب کنید.'
    Assert-Command 'npm' 'npm همراه Node.js نصب می‌شود.'
    $sdk = (& dotnet --list-sdks | Out-String)
    if ($sdk -notmatch '(^|\r?\n)10\.') { throw '.NET 10 SDK نصب نیست. نسخه SDK لازم است؛ Runtime به‌تنهایی کافی نیست.' }
    # Read Node version without JavaScript -p: Windows PowerShell 5.1 can
    # alter nested quotes when invoking native executables, corrupting JS code.
    $nodeVersionOutput = (& node --version 2>&1 | Out-String).Trim()
    if ($nodeVersionOutput -notmatch '^v?(\d+)\.') {
        throw "نسخه Node.js قابل تشخیص نیست. خروجی فرمان: $nodeVersionOutput"
    }
    $nodeMajor = [int]$Matches[1]
    Write-Host "Node.js شناسایی شد: $nodeVersionOutput"
    if ($nodeMajor -lt 22) { throw "Node.js 22 یا جدیدتر لازم است. نسخه فعلی: $nodeVersionOutput" }

    # Resolve the local SQL Server Windows service for either the default or a named instance.
    $dataSource = $SqlInstance.Trim()
    $localNames = @('.', '(local)', 'localhost', $env:COMPUTERNAME, '127.0.0.1')
    if ($localNames -contains $dataSource) {
        $serviceName = 'MSSQLSERVER'
    } elseif ($dataSource.Contains('\')) {
        $slashIndex = $dataSource.IndexOf('\')
        $hostPart = $dataSource.Substring(0, $slashIndex)
        $instancePart = $dataSource.Substring($slashIndex + 1)
        if (($localNames -contains $hostPart) -and -not [string]::IsNullOrWhiteSpace($instancePart)) {
            $serviceName = 'MSSQL$' + $instancePart
        } else {
            throw "نام Instance باید محلی باشد؛ نمونه صحیح: localhost\NIPCO2022. مقدار فعلی: $SqlInstance"
        }
    } else {
        throw "این نصب‌کننده فقط SQL Server محلی را بررسی می‌کند. از localhost یا localhost\نام‌اینستنس استفاده کنید؛ مقدار فعلی: $SqlInstance"
    }
    $sqlService = Get-Service -Name $serviceName -ErrorAction SilentlyContinue
    if (-not $sqlService) { throw "سرویس SQL Server '$serviceName' پیدا نشد. نصب Database Engine را بررسی کنید. برای نمونه، نصب پیش‌فرض باید سرویس MSSQLSERVER داشته باشد." }
    if ($sqlService.Status -ne 'Running') { Start-Service -Name $serviceName; $sqlService = Get-Service -Name $serviceName; $sqlService.WaitForStatus('Running',[TimeSpan]::FromSeconds(60)) }

    Push-Location $FrontDir
    try {
        Write-Host '[1/6] نصب وابستگی‌های رابط کاربری...' -ForegroundColor Cyan
        npm install --no-audit --no-fund --no-progress
        if ($LASTEXITCODE -ne 0) { throw 'npm install شکست خورد. اینترنت/دسترسی به registry.npmjs.org و وابستگی @tailwindcss/postcss را بررسی کنید.' }
        Write-Host '[2/6] ساخت رابط کاربری...' -ForegroundColor Cyan
        npm run build
        if ($LASTEXITCODE -ne 0) { throw 'ساخت TypeScript/Vite ناموفق بود.' }
    } finally { Pop-Location }

    Write-Host '[3/6] بازیابی بسته‌های .NET...' -ForegroundColor Cyan
    Push-Location $Root
    try { dotnet restore .\NIPCO.sln; if ($LASTEXITCODE -ne 0) { throw 'dotnet restore ناموفق بود.' } }
    finally { Pop-Location }

    $toolPath = Join-Path $env:USERPROFILE '.dotnet\tools'
    if ($env:PATH -notlike "*$toolPath*") { $env:PATH = "$toolPath;$env:PATH" }
    if (-not (Get-Command dotnet-ef -ErrorAction SilentlyContinue)) {
        dotnet tool install --global dotnet-ef --version 10.0.15
    } else {
        dotnet tool update --global dotnet-ef --version 10.0.15
    }
    if ($LASTEXITCODE -ne 0) { throw 'نصب ابزار dotnet-ef ناموفق بود.' }

    $migrationDir = Join-Path $Root 'src\Nipco.Infrastructure\Persistence\Migrations'
    $existingMigrations = if (Test-Path $migrationDir) { @(Get-ChildItem $migrationDir -Filter '*.cs' -File) } else { @() }
    if ($existingMigrations.Count -eq 0) {
        Write-Host '[4/6] ایجاد ساختار اولیه دیتابیس...' -ForegroundColor Cyan
        Push-Location $ApiDir
        try {
            dotnet ef migrations add InitialSqlServerSchema --project $InfraProject --startup-project (Join-Path $ApiDir 'Nipco.Api.csproj') --output-dir Persistence\Migrations
            if ($LASTEXITCODE -ne 0) { throw 'ساخت Migration اولیه ناموفق بود.' }
        } finally { Pop-Location }
    } else { Write-Host 'Migration موجود است؛ ساخت مجدد انجام نمی‌شود.' -ForegroundColor Yellow }

    Write-Host '[5/6] ساخت Release و به‌روزرسانی دیتابیس...' -ForegroundColor Cyan
    Push-Location $Root
    try { dotnet build .\NIPCO.sln -c Release --no-restore; if ($LASTEXITCODE -ne 0) { throw 'Build دات‌نت ناموفق بود.' } }
    finally { Pop-Location }
    $www = Join-Path $ApiDir 'wwwroot'
    $dist = Join-Path $FrontDir 'dist'
    if (-not (Test-Path (Join-Path $dist 'index.html'))) { throw 'خروجی frontend/dist/index.html ساخته نشده است.' }
    if (Test-Path $www) { Remove-Item $www -Recurse -Force }
    New-Item -ItemType Directory -Path $www -Force | Out-Null
    Copy-Item (Join-Path $dist '*') $www -Recurse -Force

    $bytes = New-Object byte[] 64
    $rng = [Security.Cryptography.RandomNumberGenerator]::Create()
    try { $rng.GetBytes($bytes) } finally { $rng.Dispose() }
    $jwt = [Convert]::ToBase64String($bytes)
    $jwtSecure = ConvertTo-SecureString -String $jwt -AsPlainText -Force
    $protectedJwt = ConvertFrom-SecureString -SecureString $jwtSecure
    Set-Content -Path (Join-Path $SecretDir 'jwt-key.dpapi') -Value $protectedJwt -Encoding ASCII

    $adminUser = (Read-Host 'نام کاربری مدیر سامانه').Trim()
    if ([string]::IsNullOrWhiteSpace($adminUser)) { throw 'نام کاربری مدیر نمی‌تواند خالی باشد.' }
    $adminSecure = Read-Host 'رمز مدیر (حداقل ۱۲ نویسه، شامل حروف بزرگ/کوچک، عدد و نماد)' -AsSecureString
    $adminPlain = Convert-SecureToPlain $adminSecure
    if ($adminPlain.Length -lt 12 -or $adminPlain -notmatch '[A-Z]' -or $adminPlain -notmatch '[a-z]' -or $adminPlain -notmatch '\d' -or $adminPlain -notmatch '[^a-zA-Z0-9]') {
        throw 'رمز واردشده با سیاست امنیتی Identity مطابقت ندارد.'
    }

    $env:ConnectionStrings__Maintenance = "Server=$dataSource;Database=NIPCO_DailyInspection;Trusted_Connection=True;Encrypt=True;TrustServerCertificate=True;MultipleActiveResultSets=True;Connect Timeout=30"
    Set-Content -Path (Join-Path $ConfigDir 'sql-instance.txt') -Value $dataSource -Encoding UTF8
    $env:Jwt__SigningKey = $jwt
    $env:Bootstrap__AdminUsername = $adminUser
    $env:Bootstrap__AdminPassword = $adminPlain
    Push-Location $ApiDir
    try {
        dotnet ef database update --project $InfraProject --startup-project (Join-Path $ApiDir 'Nipco.Api.csproj')
        if ($LASTEXITCODE -ne 0) { throw 'اتصال به SQL Server یا اعمال Migration ناموفق بود.' }
    } finally { Pop-Location }

    Write-Host '[6/6] آماده‌سازی گواهی HTTPS...' -ForegroundColor Cyan
    dotnet dev-certs https --trust
    if ($LASTEXITCODE -ne 0) { throw 'اعتمادسازی گواهی HTTPS ناموفق بود.' }
    $env:ASPNETCORE_ENVIRONMENT = 'Production'
    Write-Host 'نصب و ساخت اولیه موفق بود. سرور در حال اجراست...' -ForegroundColor Green
    Write-Host "آدرس محلی: https://localhost:$HttpsPort"
    Write-Host 'برای توقف سرور Ctrl+C را بزنید. اجرای بعدی با scripts\Start-NIPCO.ps1 است.'
    # ASP.NET Core uses the process working directory as ContentRoot by default.
    # Launch from ApiDir so StaticFiles and MapFallbackToFile resolve ApiDir\wwwroot.
    Push-Location $ApiDir
    try {
        dotnet '.\bin\Release\net10.0\Nipco.Api.dll' --urls "https://localhost:$HttpsPort"
        if ($LASTEXITCODE -ne 0) { throw 'اجرای API با خطا متوقف شد.' }
    } finally { Pop-Location }
} catch {
    Write-Host "خطا: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "گزارش کامل: $LogFile" -ForegroundColor Yellow
    throw
} finally {
    Remove-Item Env:Bootstrap__AdminPassword -ErrorAction SilentlyContinue
    Remove-Item Env:Jwt__SigningKey -ErrorAction SilentlyContinue
    Remove-Item Env:ConnectionStrings__Maintenance -ErrorAction SilentlyContinue
    $adminPlain = $null
    $adminSecure = $null
    Stop-Transcript | Out-Null
}

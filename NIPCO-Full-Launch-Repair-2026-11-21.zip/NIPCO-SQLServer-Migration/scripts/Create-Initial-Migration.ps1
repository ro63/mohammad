﻿$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$api = Join-Path $root 'src\Nipco.Api'
$infra = Join-Path $root 'src\Nipco.Infrastructure\Nipco.Infrastructure.csproj'
if (-not (Get-Command dotnet -ErrorAction SilentlyContinue)) { throw '.NET 10 SDK نصب نیست.' }
dotnet tool update --global dotnet-ef --version 10.0.15
if ($LASTEXITCODE -ne 0) { dotnet tool install --global dotnet-ef --version 10.0.15 }
Push-Location $api
try { dotnet ef migrations add InitialSqlServerSchema --project $infra --startup-project (Join-Path $api 'Nipco.Api.csproj') --output-dir Persistence\Migrations; if ($LASTEXITCODE -ne 0) { throw 'ساخت Migration ناموفق بود.' } }
finally { Pop-Location }
Write-Host 'Migration ساخته شد. پیش از اولین اجرا، آن را بازبینی و سپس dotnet ef database update را اجرا کنید.' -ForegroundColor Green

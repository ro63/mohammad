from pathlib import Path
import json
root = Path(__file__).resolve().parents[1]
front = root / "frontend"
pkg = json.loads((front / "package.json").read_text(encoding="utf-8"))
assert pkg["devDependencies"].get("@tailwindcss/postcss") == "4.3.3", "Missing Tailwind v4 PostCSS plugin dependency"
postcss = (front / "postcss.config.js").read_text(encoding="utf-8")
assert '"@tailwindcss/postcss"' in postcss and "tailwindcss: {}" not in postcss, "PostCSS config still uses the removed Tailwind v3 plugin"
css = (front / "src/index.css").read_text(encoding="utf-8")
assert '@import "tailwindcss";' in css, "Tailwind v4 CSS import is missing"
assert '@config "../tailwind.config.js";' in css, "Legacy Tailwind config is not loaded"
installer = (root / "scripts/Install-NIPCO.ps1").read_text(encoding="utf-8-sig")
assert "npm install --no-audit --no-fund --no-progress" in installer, "Installer must resolve and add the new package to package-lock"
print("PASS: Tailwind v4 PostCSS integration and installer dependency resolution are configured.")

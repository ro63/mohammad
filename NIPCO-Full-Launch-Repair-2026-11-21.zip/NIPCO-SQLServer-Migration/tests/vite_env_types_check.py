from pathlib import Path
root = Path(__file__).resolve().parents[1]
source = root / "frontend" / "src" / "vite-env.d.ts"
config = root / "frontend" / "tsconfig.app.json"
assert source.is_file(), "Missing frontend/src/vite-env.d.ts"
content = source.read_text(encoding="utf-8-sig")
assert 'reference types="vite/client"' in content, "Missing Vite client type reference"
assert '"include": ["src"]' in config.read_text(encoding="utf-8"), "tsconfig.app.json must include src"
print("PASS: Vite ImportMeta environment types are declared inside the TypeScript app include path.")

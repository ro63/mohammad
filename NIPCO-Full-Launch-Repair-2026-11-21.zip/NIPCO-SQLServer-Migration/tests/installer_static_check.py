from pathlib import Path
root = Path(__file__).resolve().parents[1]
installer = (root / 'scripts/Install-NIPCO.ps1').read_text(encoding='utf-8')
runner = (root / 'scripts/Start-NIPCO.ps1').read_text(encoding='utf-8')
layout = (root / 'frontend/src/components/Layout.tsx').read_text(encoding='utf-8')
checks = {
    'admin elevation check': 'WindowsBuiltInRole]::Administrator' in installer,
    'node and dotnet checks': "Assert-Command 'dotnet'" in installer and "Assert-Command 'node'" in installer,
    'SQL Server default/named instance validation': 'Get-Service -Name $serviceName' in installer and 'MSSQLSERVER' in installer and 'MSSQL$' in installer,
    'frontend dependency/build': 'npm install --no-audit --no-fund --no-progress' in installer and 'npm run build' in installer,
    'EF migration and database update': 'dotnet ef migrations add InitialSqlServerSchema' in installer and 'dotnet ef database update' in installer,
    'JWT DPAPI protection': 'ConvertFrom-SecureString -SecureString $jwtSecure' in installer,
    'install transcript': 'Start-Transcript' in installer and 'Stop-Transcript' in installer,
    'subsequent launch script': 'jwt-key.dpapi' in runner and 'Nipco.Api.dll' in runner,
    'history icon imported': '  History' in layout and 'icon: History' in layout,
}
for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ': ' + name)
if not all(checks.values()):
    raise SystemExit(1)

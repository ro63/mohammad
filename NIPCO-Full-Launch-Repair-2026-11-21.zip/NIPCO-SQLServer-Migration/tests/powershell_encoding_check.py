from pathlib import Path
root = Path(__file__).resolve().parents[1]
files = sorted((root / "scripts").glob("*.ps1"))
if not files:
    raise SystemExit("No PowerShell scripts found")
failed = []
for path in files:
    data = path.read_bytes()
    if not data.startswith(b"\xef\xbb\xbf"):
        failed.append(f"Missing UTF-8 BOM: {path.name}")
        continue
    text = data[3:].decode("utf-8")
    if "\ufffd" in text or "Ù" in text or "Ø" in text:
        failed.append(f"Possible encoding corruption: {path.name}")
    print(f"PASS: UTF-8 BOM and UTF-8 decode: {path.name}")
if failed:
    for item in failed:
        print("FAIL: " + item)
    raise SystemExit(1)

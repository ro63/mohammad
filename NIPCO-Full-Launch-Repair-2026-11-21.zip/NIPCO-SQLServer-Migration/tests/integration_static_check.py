from pathlib import Path
import json, xml.etree.ElementTree as ET
root = Path(__file__).resolve().parents[1]
for f in ['frontend/package.json','frontend/tsconfig.json','src/Nipco.Api/appsettings.json','src/Nipco.Api/appsettings.Development.json']:
    json.loads((root/f).read_text(encoding='utf-8'))
for f in root.glob('src/**/*.csproj'):
    ET.parse(f)
auth=(root/'frontend/src/context/AuthContext.tsx').read_text(encoding='utf-8')
data=(root/'frontend/src/context/DataContext.tsx').read_text(encoding='utf-8')
api=(root/'frontend/src/api.ts').read_text(encoding='utf-8')
program=(root/'src/Nipco.Api/Program.cs').read_text(encoding='utf-8')
inspection=(root/'frontend/src/pages/InspectionPage.tsx').read_text(encoding='utf-8')
assert "'/auth/login'" in auth and 'setToken(r.accessToken)' in auth
assert "api<ApiGroup[]>('/groups')" in data and "api('/inspections'" in data
assert "Authorization" in api and 'Bearer' in api
assert 'UseStaticFiles' in program and 'MapFallbackToFile' in program
assert "resultStatus:r.status==='ok'?'OK':'NOK'" in data
assert "setSubmitError" in inspection and "textValue" in inspection
assert 'sampleUsers' not in auth and "nipco_equipment'" not in data
print('PASS: frontend API authentication, central data fetch/write, bearer token, React static hosting and inspection submission wiring.')
print('LIMIT: Static integration assertions only; does not replace npm build, dotnet build, SQL Server integration, browser, security or load tests.')

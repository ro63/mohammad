from pathlib import Path
root = Path(__file__).resolve().parents[1]
installer = (root / 'scripts/Install-NIPCO.ps1').read_text(encoding='utf-8')
runner = (root / 'scripts/Start-NIPCO.ps1').read_text(encoding='utf-8')
config = (root / 'src/Nipco.Api/appsettings.json').read_text(encoding='utf-8')
factory = (root / 'src/Nipco.Infrastructure/Persistence/MaintenanceDbContextFactory.cs').read_text(encoding='utf-8')
guide = (root / 'SQL-SERVER-2022-INSTALL-FA.md').read_text(encoding='utf-8')
checks = {
    'default SQL data source is localhost': 'Server=localhost;' in config and "SqlInstance = 'localhost'" in installer,
    'default instance service supported': "'MSSQLSERVER'" in installer,
    'named local instance service supported': "'MSSQL$' + $instancePart" in installer,
    'instance persisted for subsequent run': "sql-instance.txt" in installer and "sql-instance.txt" in runner,
    'design-time fallback matches default instance': 'Server=localhost;' in factory,
    'SQL Server setup guide included': 'Database Engine Services' in guide and 'Add Current User' in guide,
    'Windows 11 Enterprise incompatibility documented': 'Enterprise روی Windows 11 پشتیبانی نمی‌شود' in guide,
}
for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ': ' + name)
if not all(checks.values()):
    raise SystemExit(1)

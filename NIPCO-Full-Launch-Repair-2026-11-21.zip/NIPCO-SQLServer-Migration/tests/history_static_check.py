from pathlib import Path
root=Path(__file__).resolve().parents[1]
app=(root/"frontend/src/App.tsx").read_text()
layout=(root/"frontend/src/components/Layout.tsx").read_text()
page=(root/"frontend/src/pages/InspectionHistoryPage.tsx").read_text()
controller=(root/"src/Nipco.Api/Controllers/InspectionsController.cs").read_text()
checks={
 "history route": "path=\"inspection-history\"" in app,
 "history navigation": "سابقه کنترل روزانه" in layout,
 "date and equipment filters": "from" in page and "to" in page and "equipmentId" in page,
 "server list API": "`/inspections?${p.toString()}`" in page,
 "detail API": "`/inspections/${id}`" in page,
 "result details": all(x in page for x in ["itemTitle","numericValue","minValue","maxValue","resultStatus"]),
 "technician name projection": "technicianName = db.Users" in controller,
}
for name,ok in checks.items(): print(("PASS" if ok else "FAIL")+": "+name)
if not all(checks.values()): raise SystemExit(1)

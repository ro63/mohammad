from pathlib import Path
root = Path(__file__).resolve().parents[1]
required = [
 'src/Nipco.Api/Program.cs',
 'src/Nipco.Api/Controllers/AuthController.cs',
 'src/Nipco.Api/Controllers/MasterDataController.cs',
 'src/Nipco.Api/Controllers/InspectionsController.cs',
 'src/Nipco.Api/Controllers/UsersController.cs',
 'src/Nipco.Api/Controllers/DashboardController.cs',
 'src/Nipco.Infrastructure/Persistence/MaintenanceDbContext.cs',
 'src/Nipco.Infrastructure/Persistence/MaintenanceDbContextFactory.cs',
 'src/Nipco.Domain/Entities/Entities.cs',
]
for item in required:
    assert (root/item).is_file(), f'Missing {item}'
program=(root/'src/Nipco.Api/Program.cs').read_text()
assert 'UseSqlServer' in program and 'MigrateAsync' in program and 'AddJwtBearer' in program
inspection=(root/'src/Nipco.Api/Controllers/InspectionsController.cs').read_text()
assert 'ResultStatus == "NOK"' in inspection and 'string.IsNullOrWhiteSpace(result.Comment)' in inspection
assert 'BeginTransactionAsync' in inspection
factory=(root/'src/Nipco.Infrastructure/Persistence/MaintenanceDbContextFactory.cs').read_text()
assert 'IDesignTimeDbContextFactory' in factory
ctx=(root/'src/Nipco.Infrastructure/Persistence/MaintenanceDbContext.cs').read_text()
for entity in ['EquipmentGroup','Equipment','CheckItem','DailyInspection','InspectionResult','AuditEvent']:
    assert f'DbSet<{entity}>' in ctx
print(f'PASS: {len(required)} required source files; SQL Server, JWT, EF migration startup, transactional inspection save and NOK validation markers verified.')
print('LIMIT: Static source check only; not a .NET compile, SQL integration test, Windows install test or security/load test.')

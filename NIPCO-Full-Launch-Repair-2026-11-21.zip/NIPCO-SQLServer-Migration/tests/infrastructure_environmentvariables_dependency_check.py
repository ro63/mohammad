from pathlib import Path
import xml.etree.ElementTree as ET

root = Path(__file__).resolve().parents[1]
project = root / "src" / "Nipco.Infrastructure" / "Nipco.Infrastructure.csproj"
source = root / "src" / "Nipco.Infrastructure" / "Persistence" / "MaintenanceDbContextFactory.cs"
xml = ET.parse(project).getroot()
refs = {p.attrib.get("Include"): p.attrib.get("Version") for p in xml.iter("PackageReference")}
assert refs.get("Microsoft.Extensions.Configuration.EnvironmentVariables") == "10.0.15"
assert ".AddEnvironmentVariables()" in source.read_text(encoding="utf-8")
print("Infrastructure environment variables provider dependency: PASS")

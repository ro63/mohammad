from pathlib import Path
root = Path(__file__).resolve().parents[1]
runner = (root / 'scripts/Start-NIPCO.ps1').read_text(encoding='utf-8-sig')
installer = (root / 'scripts/Install-NIPCO.ps1').read_text(encoding='utf-8-sig')
checks = {
    'runner resolves project paths from script location': "Join-Path $PSScriptRoot '..'" in runner,
    'runner republishes frontend dist to API wwwroot': "Join-Path $FrontDist '*'" in runner and "Join-Path $ApiDir 'wwwroot'" in runner,
    'runner rebuilds frontend only when dist missing': "if (-not (Test-Path (Join-Path $FrontDist 'index.html')))" in runner and 'npm run build' in runner,
    'runner recovers DPAPI key without touching SQL database': 'ConvertTo-SecureString -String $protected' in runner and 'New-AndSaveJwtKey' in runner,
    'runner checks release output': "bin\\Release\\net10.0\\Nipco.Api.dll" in runner,
    'runner launches from API content root': 'Push-Location $ApiDir' in runner and "dotnet '.\\bin\\Release\\net10.0\\Nipco.Api.dll'" in runner,
    'installer also launches from API content root': 'Push-Location $ApiDir' in installer and "dotnet '.\\bin\\Release\\net10.0\\Nipco.Api.dll'" in installer,
}
for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ': ' + name)
if not all(checks.values()):
    raise SystemExit(1)

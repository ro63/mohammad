/// <reference types="vite/client" />

// Vite augments ImportMeta with `env` through the client type declarations.
// Keep this file inside tsconfig.app.json's `src` include so `tsc -b` sees it.

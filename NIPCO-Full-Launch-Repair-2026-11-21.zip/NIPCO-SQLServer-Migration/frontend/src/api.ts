const API_BASE = (import.meta.env.VITE_API_BASE_URL || '/api').replace(/\/$/, '');
export function setToken(token: string | null) { if (token) localStorage.setItem('nipco_access_token', token); else localStorage.removeItem('nipco_access_token'); }
export function getToken() { return localStorage.getItem('nipco_access_token'); }
export async function api<T>(path: string, init: RequestInit = {}): Promise<T> {
  const headers = new Headers(init.headers);
  if (!(init.body instanceof FormData) && init.body !== undefined) headers.set('Content-Type', 'application/json');
  const token = getToken(); if (token) headers.set('Authorization', `Bearer ${token}`);
  const response = await fetch(`${API_BASE}${path}`, { ...init, headers });
  if (response.status === 204) return undefined as T;
  const contentType = response.headers.get('content-type') || '';
  const payload = contentType.includes('json') ? await response.json() : await response.text();
  if (!response.ok) {
    const message = typeof payload === 'string' ? payload : payload?.message || payload?.title || payload?.errors?.join?.('؛ ') || `خطای سرور (${response.status})`;
    throw new Error(message);
  }
  return payload as T;
}

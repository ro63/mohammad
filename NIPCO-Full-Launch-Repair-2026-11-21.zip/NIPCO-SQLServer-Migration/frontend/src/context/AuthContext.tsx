import { createContext, useContext, useState, ReactNode } from 'react';
import { User } from '../types';
import { api, setToken } from '../api';
interface AuthContextType { currentUser: User | null; login: (username: string, password: string) => Promise<boolean>; logout: () => void; isAuthenticated: boolean; }
const AuthContext = createContext<AuthContextType | undefined>(undefined);
type LoginResponse = { accessToken: string; user: { id: string; userName: string; fullName: string; roles: string[] } };
const mapRole = (role?: string): User['role'] => ({ Admin:'admin', Supervisor:'supervisor', Technician:'technician', Viewer:'viewer' } as Record<string, User['role']>)[role || ''] || 'viewer';
export function AuthProvider({ children }: { children: ReactNode }) {
  const [currentUser, setCurrentUser] = useState<User | null>(() => { try { const saved=localStorage.getItem('nipco_current_user'); return localStorage.getItem('nipco_access_token') && saved ? JSON.parse(saved) : null; } catch { return null; } });
  const login = async (username: string, password: string) => {
    try { const r = await api<LoginResponse>('/auth/login', { method:'POST', body:JSON.stringify({ username, password }) }); setToken(r.accessToken); const u: User = { id:r.user.id, fullName:r.user.fullName, username:r.user.userName, role:mapRole(r.user.roles?.[0]), personnelCode:'', password:'', mobile:'', isActive:true, createdAt:new Date() }; setCurrentUser(u); localStorage.setItem('nipco_current_user', JSON.stringify(u)); return true; }
    catch { setToken(null); return false; }
  };
  const logout = () => { setToken(null); localStorage.removeItem('nipco_current_user'); setCurrentUser(null); };
  return <AuthContext.Provider value={{ currentUser, login, logout, isAuthenticated:!!currentUser }}>{children}</AuthContext.Provider>;
}
export function useAuth() { const context=useContext(AuthContext); if (!context) throw new Error('useAuth must be used within an AuthProvider'); return context; }

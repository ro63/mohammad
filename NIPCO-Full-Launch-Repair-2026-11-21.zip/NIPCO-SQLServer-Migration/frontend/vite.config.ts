import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import { VitePWA } from 'vite-plugin-pwa'
export default defineConfig({
  plugins: [react(), VitePWA({ registerType: 'autoUpdate', includeAssets: ['favicon.svg'], manifest: { name: 'NIPCO Daily Inspection', short_name: 'NIPCO', description: 'سامانه کنترل و بازرسی روزانه تجهیزات', theme_color: '#1e40af', lang: 'fa', dir: 'rtl', display: 'standalone', start_url: '/' } })],
  server: { host: '0.0.0.0', port: 5173, proxy: { '/api': { target: 'https://localhost:7241', changeOrigin: true, secure: false } } },
  preview: { host: '0.0.0.0', port: 4173 }
})

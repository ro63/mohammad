﻿# NIPCO Daily Inspection — بسته یکپارچه‌سازی React و ASP.NET Core / SQL Server

**نوع تحویل: بسته راه‌اندازی خودکار برای Windows 11 به‌همراه سورس؛ تأیید نهایی عملیاتی منوط به اجرای نصب و تست روی رایانه مقصد است.**

## نصب تمیز و خودکار در Windows 11

1. پوشه ZIP را در مسیر دلخواهی مانند `C:\NIPCO\It1` استخراج کنید.
2. این پیش‌نیازها باید نصب باشند: **.NET 10 SDK x64**، **Node.js 22 LTS یا جدیدتر** و **SQL Server Database Engine نسخه 2022 یا جدیدتر**. نصب‌کننده از Default Instance (`localhost`) و Named Instance محلی پشتیبانی می‌کند.
3. روی `scripts\Install-NIPCO.ps1` راست‌کلیک کرده و PowerShell را با **Run as administrator** باز کنید؛ سپس از ریشه پروژه اجرا کنید:

```powershell
Set-ExecutionPolicy -Scope Process Bypass -Force
.\scripts\Install-NIPCO.ps1
```

4. نام کاربری و رمز مدیر اولیه را وارد کنید. رمز باید حداقل ۱۲ نویسه و شامل حرف بزرگ، حرف کوچک، عدد و نماد باشد.
5. نصب‌کننده وابستگی‌های React را نصب می‌کند، Frontend و Backend را در حالت Release می‌سازد، Migration اولیه را در صورت نبودن ایجاد می‌کند، دیتابیس `NIPCO_DailyInspection` را ایجاد/به‌روزرسانی می‌کند، گواهی HTTPS محلی را مورد اعتماد قرار می‌دهد و سرور را اجرا می‌کند.
6. مرورگر را در همان رایانه باز کنید: `https://localhost:7241`

برای اجرای دفعات بعدی، PowerShell را با همان حساب Windows باز کنید و اجرا کنید. اسکریپت Start-NIPCO.ps1 خروجی موجود frontend/dist را خودکار به src/Nipco.Api/wwwroot کپی می‌کند و API را از پوشه میزبان اجرا می‌کند؛ بنابراین اجرای جداگانه Build-Frontend برای شروع عادی لازم نیست:

```powershell
.\scripts\Start-NIPCO.ps1
```

کلید JWT به‌صورت رمزگذاری‌شده با DPAPI در پروفایل همان کاربر Windows ذخیره می‌شود؛ اجرای برنامه باید با همان حساب Windows انجام شود. گزارش نصب و خطاها در `%ProgramData%\NIPCO\Logs` ذخیره می‌شود. نصب‌کننده هیچ دیتابیس یا Docker volume دیگری را حذف نمی‌کند.

اگر SQL Server با نام Instance ساخته شده است، هنگام نصب از `-SqlInstance 'localhost\NIPCO2022'` استفاده کنید. نام Instance انتخاب‌شده در `%ProgramData%\NIPCO\Config\sql-instance.txt` ذخیره می‌شود و اجرای بعدی آن را خودکار می‌خواند. اجرای چندکاربره روی شبکه، HTTPS با گواهی معتبر و دسترسی شبکه باید جداگانه پیکربندی و آزمون شود.

## انتخاب نسخه و سیستم‌عامل SQL Server (مهم)

- طبق جدول سازگاری رسمی Microsoft، **SQL Server 2022 Enterprise روی Windows 11 پشتیبانی نمی‌شود**؛ نسخه‌های Developer و Standard در Windows 11 پشتیبانی می‌شوند.
- برای توسعه و آزمون روی Windows 11 از **Developer Edition** استفاده کنید؛ این Edition برای توسعه/آزمون است و مجوز استفاده Production ندارد.
- برای استفاده واقعی سازمانی از **Enterprise Edition روی Windows Server 2022 یا جدیدترِ پشتیبانی‌شده** استفاده کنید.
- در نصب SQL Server، اگر امکان انتخاب وجود دارد **Default Instance** را انتخاب کنید؛ رشته اتصال آماده `Server=localhost` است.
- راهنمای قدم‌به‌قدم نصب SQL Server 2022 در فایل `SQL-SERVER-2022-INSTALL-FA.md` قرار دارد.

## معماری
- Frontend: React 19 + TypeScript + Vite 8
- Backend: ASP.NET Core 10 Web API
- Data: EF Core 10 + SQL Server 2022 (Developer / Standard / Enterprise، مطابق سیستم‌عامل و مجوز)
- Authentication: ASP.NET Core Identity + JWT
- لایه‌ها: Domain / Application / Infrastructure / API
- در حالت استقرار، React از `wwwroot` همان ASP.NET Core سرو می‌شود و درخواست‌های `/api` به همان میزبان می‌روند؛ کاربران هیچ اتصال مستقیمی به SQL Server ندارند.

## یکپارچه‌سازی انجام‌شده
- AuthContext اکنون ورود را از `POST /api/auth/login` انجام می‌دهد؛ کاربران نمونه و رمزهای ثابت از فرآیند ورود حذف شده‌اند.
- توکن JWT به درخواست‌های API اضافه می‌شود و نقش‌های سمت سرور به نقش‌های UI تبدیل می‌شوند.
- DataContext گروه‌ها، تجهیزات، آیتم‌های چک‌لیست و سوابق بازرسی را از API می‌خواند؛ داده‌های اصلی دیگر در localStorage ذخیره نمی‌شوند.
- افزودن گروه، تجهیز و آیتم چک‌لیست به endpointهای API وصل شده است.
- فرم بازرسی به `POST /api/inspections` متصل شده و نتیجه NOK و توضیح عیب را می‌فرستد؛ مقدار عددی خارج از محدوده به‌صورت NOK تشخیص داده می‌شود.
- API قبل از ثبت، حضور همه آیتم‌های اجباری چک‌لیست گروه تجهیز را بررسی می‌کند و توضیح برای NOK را اجباری می‌داند.
- خروجی endpointهای Master Data به DTOهای ساده تبدیل شده تا چرخه ارجاع JSON ایجاد نشود.
- ASP.NET Core قابلیت سرو فایل‌های React از `wwwroot` و fallback مسیرهای React Router را دارد.
- اسکریپت‌های ساخت Frontend و ایجاد Migration اولیه اضافه شده‌اند.

## پوشه‌ها
- `frontend/` سورس کامل React متصل‌شده به API
- `src/Nipco.Api/` میزبان Web API و سرو فایل‌های Frontend
- `src/Nipco.Domain/` مدل‌های دامنه
- `src/Nipco.Application/` قراردادهای درخواست
- `src/Nipco.Infrastructure/` DbContext، Identity و SQL Server
- `scripts/Build-Frontend.ps1` ساخت React و کپی خروجی به `wwwroot`
- `scripts/Install-NIPCO.ps1` نصب تمیز، ساخت Release، Migration و اجرای اولیه در Windows 11
- `scripts/Start-NIPCO.ps1` اجرای بعدی برنامه با کلید JWT رمزگذاری‌شده
- `scripts/Create-Initial-Migration.ps1` ساخت Migration اولیه EF Core
- `INTEGRATION-REPORT-FA.txt` گزارش دقیق تست‌ها و محدودیت‌ها

## پیش‌نیاز Windows 11 x64
1. .NET 10 SDK x64
2. Node.js 22 LTS یا جدیدتر و npm
3. SQL Server Database Engine 2022 یا جدیدتر؛ نصب پیش‌فرض (Default Instance) توصیه می‌شود
4. SSMS برای مدیریت و بررسی دیتابیس
5. PowerShell 5.1 یا جدیدتر

## راه‌اندازی توسعه‌ای
از PowerShell در ریشه پوشه `NIPCO-SQLServer-Migration`:

```powershell
# 1) گواهی توسعه HTTPS را مورد اعتماد ویندوز قرار دهید
dotnet dev-certs https --trust

# 2) کلید JWT تصادفی بسازید و فقط در نشست فعلی نگه دارید
$bytes = New-Object byte[] 48
$rng = New-Object System.Security.Cryptography.RNGCryptoServiceProvider
try { $rng.GetBytes($bytes) } finally { $rng.Dispose() }
$env:JWT__SIGNINGKEY = [Convert]::ToBase64String($bytes)

# 3) مشخصات مدیر اولیه را تعاملی وارد کنید؛ رمز را در فایل ننویسید
$env:Bootstrap__AdminUsername = Read-Host 'نام کاربری مدیر اولیه'
$secure = Read-Host 'رمز قوی مدیر اولیه' -AsSecureString
$ptr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
try { $env:Bootstrap__AdminPassword = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr) }
finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr) }

# 4) Migration اولیه و Restore/Build
.\scripts\Create-Initial-Migration.ps1
dotnet restore .\NIPCO.sln
dotnet build .\NIPCO.sln -c Release

# 5) ساخت رابط React و قراردادن آن کنار API
.\scripts\Build-Frontend.ps1

# 6) اجرای API (در یک پنجره PowerShell)
cd .\src\Nipco.Api
dotnet run --urls 'https://localhost:7241;http://localhost:5241'
```

سپس در مرورگر `https://localhost:7241` را باز کنید. دیتابیس `NIPCO_DailyInspection` در SQL Server نصب‌شده ایجاد/به‌روزرسانی می‌شود، مشروط به اینکه سرویس Database Engine در دسترس باشد و حساب Windows اجرای API مجوز لازم را داشته باشد.

### اجرای Frontend در حالت توسعه جداگانه
در پنجره دوم PowerShell:

```powershell
cd .\frontend
npm install
npm run dev
```

Vite روی پورت 5173 اجرا می‌شود و مسیر `/api` را به `https://localhost:7241` proxy می‌کند. اگر گواهی توسعه مورد اعتماد نباشد، ابتدا `dotnet dev-certs https --trust` را اجرا و مرورگر را مجدداً باز کنید.

## اتصال SQL Server
رشته اتصال پیش‌فرض در `src/Nipco.Api/appsettings.json`:

`Server=localhost;Database=NIPCO_DailyInspection;Trusted_Connection=True;Encrypt=True;TrustServerCertificate=True;MultipleActiveResultSets=True;Connect Timeout=30`

اسکریپت نصب فعلی، SQL Server محلی روی همان رایانه را بررسی و راه‌اندازی می‌کند؛ نصب دیتابیس روی میزبان جداگانه به تنظیم دستی Connection String و مجوز حساب سرویس نیاز دارد و در این بسته به‌صورت خودکار پیکربندی نشده است. برای ساختار ساده و قابل آزمون، ابتدا API و SQL Server را روی همان سرور نصب کنید. در محیط عملیاتی از گواهی معتبر SQL Server و `TrustServerCertificate=False` استفاده کنید. پورت SQL را برای کاربران نهایی باز نکنید؛ کاربران فقط به API دسترسی داشته باشند.

## نکات امنیتی
- JWT Signing Key و رمز مدیر اولیه داخل ZIP یا appsettings ذخیره نشده‌اند؛ آن‌ها را در محیط امن سرویس تنظیم کنید.
- در نمونه توسعه، `TrustServerCertificate=True` صرفاً برای سهولت راه‌اندازی محلی است و برای محیط عملیاتی باید با گواهی معتبر SQL Server و `TrustServerCertificate=False` جایگزین شود.
- توکن سمت مرورگر فعلاً در localStorage نگهداری می‌شود؛ برای انتشار نهایی بهتر است BFF یا کوکی HttpOnly/Secure/SameSite و سیاست ضد-CSRF پیاده‌سازی شود.
- تنظیم مجوزها و نقش‌های API مرجع نهایی است؛ نقش UI صرفاً برای نمایش منو است.
- قبل از هر Migration روی دیتابیس موجود، Backup معتبر تهیه و Migration بازبینی شود. هیچ اسکریپت این بسته دیتابیس موجود را حذف نمی‌کند.

## محدودیت‌های باقیمانده
- مدیریت کاربران UI به endpointهای Users هنوز متصل نشده است.
- ویرایش و غیرفعال‌سازی گروه، تجهیز و آیتم چک‌لیست در UI/API کامل نیست.
- گردش کار تأیید سرپرست، پیش‌نویس، اصلاح/ابطال کنترل‌شده، نسخه‌بندی چک‌لیست و چک‌لیست اختصاصی هر تجهیز تکمیل نشده است.
- QR camera، فایل/عکس/ویدئو/صوت، Excel/PDF، تقویم شمسی کامل، گزارش‌ساز و Backup/Restore عملیاتی تکمیل نشده‌اند.
- گزارش‌ها و صفحات جزئیات هنوز به‌طور کامل به endpointهای گزارش/جزئیات متصل نشده‌اند.
- تست واقعی Windows، SQL Server 2022، Build نهایی، شبکه چندکاربره و بار ۳۰ کاربر هنوز انجام نشده است.

## وضعیت آزمون این بسته
`tests/static_check.py` بررسی ایستای سورس را انجام می‌دهد. در محیط تولید این بسته، .NET SDK نصب نبود و اجرای `npm install` نیز به علت محدودیت زمان/دسترسی مخزن npm کامل نشد؛ بنابراین ادعای موفقیت `dotnet build` یا `npm run build` وجود ندارد. قبل از ورود داده واقعی باید تمام فرمان‌های راه‌اندازی بالا روی Windows هدف اجرا و خطاها برطرف شوند.

## مشاهده سابقه کنترل روزانه
پس از ورود به سامانه، از منوی سمت راست گزینه «سابقه کنترل روزانه» را انتخاب کنید. فهرست از API و پایگاه داده SQL Server خوانده می‌شود و امکان فیلتر بر اساس بازه تاریخ و تجهیز، جستجو در کد/نام تجهیز و نام بازرس، صفحه‌بندی و مشاهده جزئیات هر بازرسی را فراهم می‌کند. در جزئیات، مقادیر ثبت‌شده، حدود مجاز، نتیجه OK/NOK/NA و توضیحات هر آیتم نمایش داده می‌شود. این صفحه فقط سوابقی را نشان می‌دهد که در پایگاه داده ثبت شده‌اند؛ داده آزمایشی یا سابقه ساختگی تولید نمی‌کند.

## اصلاح اسکریپت اجرا برای نصب موجود (۲۱ نوامبر ۲۰۲۶)
اگر نصب اولیه و ایجاد دیتابیس موفق شده است، برای اصلاح مسیر wwwroot فقط ZIP به‌روزرسانی را روی پوشه فعلی استخراج و فایل‌های هم‌نام را جایگزین کنید؛ پوشه پروژه را پاک نکنید و Install-NIPCO.ps1 را دوباره اجرا نکنید. اسکریپت Start-NIPCO.ps1 جدید خروجی frontend/dist را خودکار به src/Nipco.Api/wwwroot کپی می‌کند و API را از پوشه src/Nipco.Api اجرا می‌کند. راهنمای کامل در UPDATE-INSTALLED-REPAIR-FA.txt است.

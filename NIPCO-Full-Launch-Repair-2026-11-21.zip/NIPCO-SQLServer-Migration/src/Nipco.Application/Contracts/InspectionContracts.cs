namespace Nipco.Application.Contracts;

public sealed record CreateEquipmentRequest(string Code, string Name, string Type, Guid GroupId, string Site, string Location, string? QrCode);
public sealed record CreateGroupRequest(string Code, string Name, string? Description);
public sealed record CreateCheckItemRequest(string Code, string Title, string Section, string ValueType, string? Unit, decimal? MinValue, decimal? MaxValue, bool IsRequired, int SortOrder, Guid[] EquipmentGroupIds);
public sealed record InspectionResultRequest(Guid CheckItemId, string ResultStatus, decimal? NumericValue, string? TextValue, string? Comment);
public sealed record SubmitInspectionRequest(Guid EquipmentId, DateOnly InspectionDate, string ShiftCode, InspectionResultRequest[] Results);

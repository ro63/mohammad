using Microsoft.AspNetCore.Identity;

namespace Nipco.Infrastructure.Persistence;

public sealed class AppUser : IdentityUser
{
    public string FullName { get; set; } = "";
    public string PersonnelCode { get; set; } = "";
    public bool IsActive { get; set; } = true;
    public DateTime CreatedUtc { get; set; } = DateTime.UtcNow;
}

using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Nipco.Domain.Entities;

namespace Nipco.Infrastructure.Persistence;

public sealed class MaintenanceDbContext(DbContextOptions<MaintenanceDbContext> options)
    : IdentityDbContext<AppUser>(options)
{
    public DbSet<EquipmentGroup> EquipmentGroups => Set<EquipmentGroup>();
    public DbSet<Equipment> Equipment => Set<Equipment>();
    public DbSet<CheckItem> CheckItems => Set<CheckItem>();
    public DbSet<CheckItemGroup> CheckItemGroups => Set<CheckItemGroup>();
    public DbSet<DailyInspection> DailyInspections => Set<DailyInspection>();
    public DbSet<InspectionResult> InspectionResults => Set<InspectionResult>();
    public DbSet<AuditEvent> AuditEvents => Set<AuditEvent>();

    protected override void OnModelCreating(ModelBuilder b)
    {
        base.OnModelCreating(b);
        b.Entity<EquipmentGroup>().HasIndex(x => x.Code).IsUnique();
        b.Entity<EquipmentGroup>().Property(x => x.Code).HasMaxLength(40).IsRequired();
        b.Entity<EquipmentGroup>().Property(x => x.Name).HasMaxLength(160).IsRequired();
        b.Entity<Equipment>().HasIndex(x => x.Code).IsUnique();
        b.Entity<Equipment>().HasIndex(x => x.QrCode).IsUnique().HasFilter("[QrCode] IS NOT NULL");
        b.Entity<Equipment>().Property(x => x.Code).HasMaxLength(60).IsRequired();
        b.Entity<Equipment>().Property(x => x.Name).HasMaxLength(200).IsRequired();
        b.Entity<Equipment>().HasOne(x => x.Group).WithMany(x => x.Equipment).HasForeignKey(x => x.GroupId).OnDelete(DeleteBehavior.Restrict);
        b.Entity<CheckItem>().HasIndex(x => x.Code).IsUnique();
        b.Entity<CheckItem>().Property(x => x.Title).HasMaxLength(300).IsRequired();
        b.Entity<CheckItemGroup>().HasKey(x => new { x.CheckItemId, x.EquipmentGroupId });
        b.Entity<CheckItemGroup>().HasOne(x => x.CheckItem).WithMany(x => x.Groups).HasForeignKey(x => x.CheckItemId).OnDelete(DeleteBehavior.Cascade);
        b.Entity<CheckItemGroup>().HasOne(x => x.EquipmentGroup).WithMany(x => x.CheckItemGroups).HasForeignKey(x => x.EquipmentGroupId).OnDelete(DeleteBehavior.Restrict);
        b.Entity<DailyInspection>().HasIndex(x => new { x.EquipmentId, x.InspectionDate, x.ShiftCode });
        b.Entity<DailyInspection>().HasOne(x => x.Equipment).WithMany().HasForeignKey(x => x.EquipmentId).OnDelete(DeleteBehavior.Restrict);
        b.Entity<DailyInspection>().HasOne<AppUser>().WithMany().HasForeignKey(x => x.TechnicianId).OnDelete(DeleteBehavior.Restrict);
        b.Entity<InspectionResult>().HasOne(x => x.DailyInspection).WithMany(x => x.Results).HasForeignKey(x => x.DailyInspectionId).OnDelete(DeleteBehavior.Cascade);
        b.Entity<InspectionResult>().HasOne(x => x.CheckItem).WithMany().HasForeignKey(x => x.CheckItemId).OnDelete(DeleteBehavior.Restrict);
        b.Entity<AuditEvent>().HasIndex(x => x.CreatedUtc);
        b.Entity<AuditEvent>().Property(x => x.Details).HasMaxLength(3000);
    }
}

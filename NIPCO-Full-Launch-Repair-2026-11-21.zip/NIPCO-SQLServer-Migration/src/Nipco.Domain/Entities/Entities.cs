namespace Nipco.Domain.Entities;

public sealed class EquipmentGroup
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string Code { get; set; } = "";
    public string Name { get; set; } = "";
    public string? Description { get; set; }
    public bool IsActive { get; set; } = true;
    public DateTime CreatedUtc { get; set; } = DateTime.UtcNow;
    public ICollection<Equipment> Equipment { get; set; } = new List<Equipment>();
    public ICollection<CheckItemGroup> CheckItemGroups { get; set; } = new List<CheckItemGroup>();
}

public sealed class Equipment
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string Code { get; set; } = "";
    public string Name { get; set; } = "";
    public string Type { get; set; } = "";
    public Guid GroupId { get; set; }
    public EquipmentGroup? Group { get; set; }
    public string Site { get; set; } = "";
    public string Location { get; set; } = "";
    public string? QrCode { get; set; }
    public bool IsActive { get; set; } = true;
    public DateTime CreatedUtc { get; set; } = DateTime.UtcNow;
}

public sealed class CheckItem
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string Code { get; set; } = "";
    public string Title { get; set; } = "";
    public string Section { get; set; } = "General";
    public string ValueType { get; set; } = "Boolean"; // Boolean, Numeric, Text
    public string? Unit { get; set; }
    public decimal? MinValue { get; set; }
    public decimal? MaxValue { get; set; }
    public bool IsRequired { get; set; } = true;
    public bool IsActive { get; set; } = true;
    public int SortOrder { get; set; }
    public ICollection<CheckItemGroup> Groups { get; set; } = new List<CheckItemGroup>();
}

public sealed class CheckItemGroup
{
    public Guid CheckItemId { get; set; }
    public CheckItem? CheckItem { get; set; }
    public Guid EquipmentGroupId { get; set; }
    public EquipmentGroup? EquipmentGroup { get; set; }
}

public sealed class DailyInspection
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid EquipmentId { get; set; }
    public Equipment? Equipment { get; set; }
    public string TechnicianId { get; set; } = "";
    public DateOnly InspectionDate { get; set; }
    public string ShiftCode { get; set; } = "A";
    public string State { get; set; } = "Draft"; // Draft, Submitted, Reviewed
    public DateTime CreatedUtc { get; set; } = DateTime.UtcNow;
    public DateTime? SubmittedUtc { get; set; }
    public ICollection<InspectionResult> Results { get; set; } = new List<InspectionResult>();
}

public sealed class InspectionResult
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid DailyInspectionId { get; set; }
    public DailyInspection? DailyInspection { get; set; }
    public Guid CheckItemId { get; set; }
    public CheckItem? CheckItem { get; set; }
    public string ResultStatus { get; set; } = "OK"; // OK, NOK, NA
    public decimal? NumericValue { get; set; }
    public string? TextValue { get; set; }
    public string? Comment { get; set; }
    public DateTime RecordedUtc { get; set; } = DateTime.UtcNow;
}

public sealed class AuditEvent
{
    public long Id { get; set; }
    public string? ActorId { get; set; }
    public string EventType { get; set; } = "";
    public string EntityType { get; set; } = "";
    public string EntityId { get; set; } = "";
    public string? Details { get; set; }
    public DateTime CreatedUtc { get; set; } = DateTime.UtcNow;
}

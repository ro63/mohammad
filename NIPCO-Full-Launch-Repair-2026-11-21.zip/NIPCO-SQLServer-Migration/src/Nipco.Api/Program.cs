using System.IdentityModel.Tokens.Jwt;
using System.Text;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Nipco.Infrastructure.Persistence;

var builder = WebApplication.CreateBuilder(args);
var connection = builder.Configuration.GetConnectionString("Maintenance")
    ?? throw new InvalidOperationException("ConnectionStrings:Maintenance is missing.");
builder.Services.AddDbContext<MaintenanceDbContext>(o => o.UseSqlServer(connection, sql => sql.EnableRetryOnFailure(5)));
builder.Services.AddIdentityCore<AppUser>(o =>
{
    o.Password.RequiredLength = 12;
    o.Password.RequireDigit = true;
    o.Password.RequireUppercase = true;
    o.Password.RequireLowercase = true;
    o.Password.RequireNonAlphanumeric = true;
    o.Lockout.MaxFailedAccessAttempts = 5;
    o.Lockout.DefaultLockoutTimeSpan = TimeSpan.FromMinutes(15);
    o.User.RequireUniqueEmail = false;
})
.AddRoles<IdentityRole>()
.AddEntityFrameworkStores<MaintenanceDbContext>()
.AddSignInManager();
var jwtKey = builder.Configuration["Jwt:SigningKey"];
if (string.IsNullOrWhiteSpace(jwtKey) || Encoding.UTF8.GetByteCount(jwtKey) < 32)
    throw new InvalidOperationException("Set JWT__SIGNINGKEY to a random secret of at least 32 UTF-8 bytes.");
var issuer = builder.Configuration["Jwt:Issuer"] ?? "NIPCO.DailyInspection";
var audience = builder.Configuration["Jwt:Audience"] ?? "NIPCO.DailyInspection.Client";
builder.Services.AddAuthentication("Bearer").AddJwtBearer("Bearer", o =>
{
    o.TokenValidationParameters = new TokenValidationParameters
    {
        ValidateIssuer = true, ValidIssuer = issuer,
        ValidateAudience = true, ValidAudience = audience,
        ValidateIssuerSigningKey = true,
        IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtKey)),
        ValidateLifetime = true, ClockSkew = TimeSpan.FromSeconds(30)
    };
});
builder.Services.AddAuthorization(o =>
{
    o.AddPolicy("InspectionWrite", p => p.RequireRole("Admin", "Supervisor", "Technician"));
    o.AddPolicy("MasterDataWrite", p => p.RequireRole("Admin", "Supervisor"));
});
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddOpenApi();
builder.Services.AddHealthChecks().AddDbContextCheck<MaintenanceDbContext>();
builder.Services.AddCors(o => o.AddPolicy("Frontend", p =>
{
    var origins = builder.Configuration.GetSection("Cors:AllowedOrigins").Get<string[]>() ?? [];
    if (origins.Length > 0) p.WithOrigins(origins).AllowAnyHeader().AllowAnyMethod();
}));

var app = builder.Build();
app.UseExceptionHandler(error => error.Run(async context =>
{
    context.Response.StatusCode = StatusCodes.Status500InternalServerError;
    context.Response.ContentType = "application/problem+json";
    await context.Response.WriteAsJsonAsync(new { title = "خطای داخلی سرور", status = 500, traceId = context.TraceIdentifier });
}));
app.UseHttpsRedirection();
app.UseDefaultFiles();
app.UseStaticFiles();
app.UseCors("Frontend");
app.UseAuthentication();
app.UseAuthorization();
app.MapControllers();
app.MapHealthChecks("/health");
if (app.Environment.IsDevelopment()) app.MapOpenApi();
app.MapFallbackToFile("index.html");

// Roles are provisioned automatically. Admin account is created only when explicit environment variables exist.
using (var scope = app.Services.CreateScope())
{
    var services = scope.ServiceProvider;
    var db = services.GetRequiredService<MaintenanceDbContext>();
    await db.Database.MigrateAsync();
    var roles = services.GetRequiredService<RoleManager<IdentityRole>>();
    foreach (var role in new[] { "Admin", "Supervisor", "Technician", "Viewer" })
        if (!await roles.RoleExistsAsync(role)) await roles.CreateAsync(new IdentityRole(role));
    var username = app.Configuration["Bootstrap:AdminUsername"];
    var password = app.Configuration["Bootstrap:AdminPassword"];
    if (!string.IsNullOrWhiteSpace(username) && !string.IsNullOrWhiteSpace(password))
    {
        var users = services.GetRequiredService<UserManager<AppUser>>();
        if (await users.FindByNameAsync(username) is null)
        {
            var admin = new AppUser { UserName = username, FullName = "NIPCO System Administrator", EmailConfirmed = false, IsActive = true };
            var result = await users.CreateAsync(admin, password);
            if (!result.Succeeded) throw new InvalidOperationException("Bootstrap admin creation failed: " + string.Join("; ", result.Errors.Select(e => e.Description)));
            await users.AddToRoleAsync(admin, "Admin");
        }
    }
}
app.Run();

public partial class Program { }

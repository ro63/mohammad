using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using Nipco.Infrastructure.Persistence;

namespace Nipco.Api.Controllers;

[ApiController, Route("api/auth")]
public sealed class AuthController(UserManager<AppUser> users, SignInManager<AppUser> signIn, IConfiguration config) : ControllerBase
{
    public sealed record LoginRequest(string Username, string Password);
    [AllowAnonymous, HttpPost("login")]
    public async Task<IActionResult> Login(LoginRequest request)
    {
        if (string.IsNullOrWhiteSpace(request.Username) || string.IsNullOrWhiteSpace(request.Password)) return BadRequest(new { message = "نام کاربری و رمز عبور الزامی است." });
        var user = await users.FindByNameAsync(request.Username.Trim());
        if (user is null || !user.IsActive) return Unauthorized(new { message = "اطلاعات ورود نامعتبر است." });
        var check = await signIn.CheckPasswordSignInAsync(user, request.Password, lockoutOnFailure: true);
        if (!check.Succeeded) return Unauthorized(new { message = "اطلاعات ورود نامعتبر است یا حساب موقتاً قفل شده است." });
        var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(config["Jwt:SigningKey"]!));
        var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
        var claims = new List<Claim> { new(JwtRegisteredClaimNames.Sub, user.Id), new(ClaimTypes.NameIdentifier, user.Id), new(ClaimTypes.Name, user.UserName ?? ""), new("fullName", user.FullName) };
        claims.AddRange((await users.GetRolesAsync(user)).Select(r => new Claim(ClaimTypes.Role, r)));
        var expires = DateTime.UtcNow.AddMinutes(int.TryParse(config["Jwt:LifetimeMinutes"], out var mins) ? Math.Clamp(mins, 5, 240) : 30);
        var token = new JwtSecurityToken(config["Jwt:Issuer"] ?? "NIPCO.DailyInspection", config["Jwt:Audience"] ?? "NIPCO.DailyInspection.Client", claims, DateTime.UtcNow, expires, creds);
        return Ok(new { accessToken = new JwtSecurityTokenHandler().WriteToken(token), expiresUtc = expires, user = new { user.Id, user.UserName, user.FullName, roles = await users.GetRolesAsync(user) } });
    }
}

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Nipco.Infrastructure.Persistence;

namespace Nipco.Api.Controllers;

[ApiController, Route("api/users"), Authorize(Roles = "Admin")]
public sealed class UsersController(UserManager<AppUser> users) : ControllerBase
{
    public sealed record CreateUserRequest(string Username, string Password, string FullName, string PersonnelCode, string Role);
    public sealed record SetActiveRequest(bool IsActive);

    [HttpGet]
    public async Task<IActionResult> List() => Ok(await users.Users.AsNoTracking().OrderBy(x => x.UserName).Select(x => new { x.Id, x.UserName, x.FullName, x.PersonnelCode, x.IsActive }).ToListAsync());

    [HttpPost]
    public async Task<IActionResult> Create(CreateUserRequest r)
    {
        if (string.IsNullOrWhiteSpace(r.Username) || string.IsNullOrWhiteSpace(r.FullName) || string.IsNullOrWhiteSpace(r.Role)) return BadRequest(new { message = "نام کاربری، نام کامل و نقش الزامی است." });
        if (r.Role is not ("Admin" or "Supervisor" or "Technician" or "Viewer")) return BadRequest(new { message = "نقش انتخاب‌شده معتبر نیست." });
        var user = new AppUser { UserName = r.Username.Trim(), FullName = r.FullName.Trim(), PersonnelCode = r.PersonnelCode.Trim(), IsActive = true };
        var created = await users.CreateAsync(user, r.Password);
        if (!created.Succeeded) return BadRequest(new { errors = created.Errors.Select(e => e.Description) });
        await users.AddToRoleAsync(user, r.Role);
        return Created($"/api/users/{user.Id}", new { user.Id, user.UserName, user.FullName, Role = r.Role });
    }

    [HttpPatch("{id}/active")]
    public async Task<IActionResult> SetActive(string id, SetActiveRequest r)
    {
        var user = await users.FindByIdAsync(id);
        if (user is null) return NotFound();
        if (!r.IsActive && User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value == id) return BadRequest(new { message = "امکان غیرفعال کردن حساب جاری وجود ندارد." });
        user.IsActive = r.IsActive;
        var result = await users.UpdateAsync(user);
        return result.Succeeded ? NoContent() : BadRequest(new { errors = result.Errors.Select(e => e.Description) });
    }

    [HttpPost("{id}/reset-password")]
    public async Task<IActionResult> ResetPassword(string id, [FromBody] string newPassword)
    {
        var user = await users.FindByIdAsync(id);
        if (user is null) return NotFound();
        var token = await users.GeneratePasswordResetTokenAsync(user);
        var result = await users.ResetPasswordAsync(user, token, newPassword);
        return result.Succeeded ? NoContent() : BadRequest(new { errors = result.Errors.Select(e => e.Description) });
    }
}

using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Nipco.Application.Contracts;
using Nipco.Domain.Entities;
using Nipco.Infrastructure.Persistence;

namespace Nipco.Api.Controllers;

[ApiController, Route("api/inspections"), Authorize]
public sealed class InspectionsController(MaintenanceDbContext db) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> List([FromQuery] DateOnly? from, [FromQuery] DateOnly? to, [FromQuery] Guid? equipmentId, [FromQuery] string? search, [FromQuery] int page = 1, [FromQuery] int pageSize = 50)
    {
        page = Math.Max(1, page); pageSize = Math.Clamp(pageSize, 1, 200);
        var q = db.DailyInspections.AsNoTracking().Include(x => x.Equipment).AsQueryable();
        if (from.HasValue) q = q.Where(x => x.InspectionDate >= from.Value);
        if (to.HasValue) q = q.Where(x => x.InspectionDate <= to.Value);
        if (equipmentId.HasValue) q = q.Where(x => x.EquipmentId == equipmentId.Value);
        var term = search?.Trim();
        if (!string.IsNullOrWhiteSpace(term)) q = q.Where(x => x.Equipment!.Code.Contains(term) || x.Equipment.Name.Contains(term) || db.Users.Any(u => u.Id == x.TechnicianId && u.FullName.Contains(term)));
        var total = await q.CountAsync();
        var rows = await q.OrderByDescending(x => x.InspectionDate).ThenByDescending(x => x.CreatedUtc).Skip((page - 1) * pageSize).Take(pageSize).Select(x => new { x.Id, x.EquipmentId, equipmentCode = x.Equipment!.Code, equipmentName = x.Equipment.Name, x.TechnicianId, technicianName = db.Users.Where(u => u.Id == x.TechnicianId).Select(u => u.FullName).FirstOrDefault(), x.InspectionDate, x.ShiftCode, x.State, x.CreatedUtc, x.SubmittedUtc, resultCount = x.Results.Count, okCount = x.Results.Count(r => r.ResultStatus == "OK"), nokCount = x.Results.Count(r => r.ResultStatus == "NOK"), naCount = x.Results.Count(r => r.ResultStatus == "NA") }).ToListAsync();
        return Ok(new { total, page, pageSize, items = rows });
    }

    [HttpGet("{id:guid}")]
    public async Task<IActionResult> Get(Guid id)
    {
        var row = await db.DailyInspections.AsNoTracking().Where(x => x.Id == id).Select(x => new
        {
            x.Id, x.EquipmentId, equipmentCode = x.Equipment!.Code, equipmentName = x.Equipment.Name,
            equipmentLocation = x.Equipment.Location, x.TechnicianId,
            technicianName = db.Users.Where(u => u.Id == x.TechnicianId).Select(u => u.FullName).FirstOrDefault(),
            x.InspectionDate, x.ShiftCode, x.State, x.CreatedUtc, x.SubmittedUtc,
            results = x.Results.OrderBy(r => r.CheckItem!.SortOrder).Select(r => new
            {
                r.Id, r.CheckItemId, itemCode = r.CheckItem!.Code, itemTitle = r.CheckItem.Title,
                section = r.CheckItem.Section, valueType = r.CheckItem.ValueType, unit = r.CheckItem.Unit,
                minValue = r.CheckItem.MinValue, maxValue = r.CheckItem.MaxValue,
                r.ResultStatus, r.NumericValue, r.TextValue, r.Comment, r.RecordedUtc
            }).ToList()
        }).SingleOrDefaultAsync();
        return row is null ? NotFound() : Ok(row);
    }

    [HttpPost, Authorize(Policy = "InspectionWrite")]
    public async Task<IActionResult> Submit(SubmitInspectionRequest r)
    {
        if (r.EquipmentId == Guid.Empty || string.IsNullOrWhiteSpace(r.ShiftCode)) return BadRequest(new { message = "تجهیز و شیفت الزامی است." });
        if (r.Results is null || r.Results.Length == 0) return BadRequest(new { message = "حداقل یک نتیجه بازرسی لازم است." });
        if (r.Results.Select(x => x.CheckItemId).Distinct().Count() != r.Results.Length) return BadRequest(new { message = "آیتم تکراری در نتایج وجود دارد." });
        var equipment = await db.Equipment.Include(x => x.Group).SingleOrDefaultAsync(x => x.Id == r.EquipmentId && x.IsActive);
        if (equipment is null) return BadRequest(new { message = "تجهیز فعال و معتبر یافت نشد." });
        var ids = r.Results.Select(x => x.CheckItemId).ToArray();
        var definitions = await db.CheckItems.Where(x => x.IsActive && ids.Contains(x.Id) && x.Groups.Any(g => g.EquipmentGroupId == equipment.GroupId)).ToDictionaryAsync(x => x.Id);
        if (definitions.Count != ids.Length) return BadRequest(new { message = "یک یا چند آیتم برای گروه این تجهیز تعریف نشده یا غیرفعال است." });
        var requiredIds = await db.CheckItems.Where(x => x.IsActive && x.IsRequired && x.Groups.Any(g => g.EquipmentGroupId == equipment.GroupId)).Select(x => x.Id).ToListAsync();
        var missingRequired = requiredIds.Except(ids).ToArray();
        if (missingRequired.Length > 0) return BadRequest(new { message = "تمام آیتم‌های اجباری چک‌لیست باید پاسخ داده شوند." });
        foreach (var result in r.Results)
        {
            var item = definitions[result.CheckItemId];
            if (result.ResultStatus is not ("OK" or "NOK" or "NA")) return BadRequest(new { message = $"وضعیت نتیجه برای «{item.Title}» نامعتبر است." });
            if (item.IsRequired && result.ResultStatus == "NA") return BadRequest(new { message = $"آیتم «{item.Title}» اجباری است و نمی‌تواند نامرتبط ثبت شود." });
            if (result.ResultStatus == "NOK" && string.IsNullOrWhiteSpace(result.Comment)) return BadRequest(new { message = $"برای نتیجه NOK در «{item.Title}» درج توضیح الزامی است." });
            if (item.ValueType == "Numeric")
            {
                if (item.IsRequired && result.ResultStatus != "NA" && !result.NumericValue.HasValue) return BadRequest(new { message = $"مقدار عددی «{item.Title}» الزامی است." });
                if (result.NumericValue.HasValue && ((item.MinValue.HasValue && result.NumericValue < item.MinValue) || (item.MaxValue.HasValue && result.NumericValue > item.MaxValue)))
                    if (result.ResultStatus != "NOK" || string.IsNullOrWhiteSpace(result.Comment)) return BadRequest(new { message = $"مقدار «{item.Title}» خارج از محدوده مجاز است؛ نتیجه را NOK کرده و توضیح وارد کنید." });
            }
            else if (item.ValueType == "Text" && item.IsRequired && result.ResultStatus != "NA" && string.IsNullOrWhiteSpace(result.TextValue)) return BadRequest(new { message = $"مقدار متنی «{item.Title}» الزامی است." });
        }
        var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
        if (string.IsNullOrEmpty(userId)) return Unauthorized();
        var exists = await db.DailyInspections.AnyAsync(x => x.EquipmentId == r.EquipmentId && x.InspectionDate == r.InspectionDate && x.ShiftCode == r.ShiftCode && x.State != "Draft");
        if (exists) return Conflict(new { message = "برای این تجهیز، تاریخ و شیفت قبلاً بازرسی نهایی ثبت شده است." });
        var entity = new DailyInspection { EquipmentId = r.EquipmentId, TechnicianId = userId, InspectionDate = r.InspectionDate, ShiftCode = r.ShiftCode.Trim(), State = "Submitted", SubmittedUtc = DateTime.UtcNow };
        foreach (var x in r.Results) entity.Results.Add(new InspectionResult { CheckItemId = x.CheckItemId, ResultStatus = x.ResultStatus, NumericValue = x.NumericValue, TextValue = x.TextValue?.Trim(), Comment = x.Comment?.Trim() });
        await using var tx = await db.Database.BeginTransactionAsync();
        db.DailyInspections.Add(entity);
        db.AuditEvents.Add(new AuditEvent { ActorId = userId, EventType = "InspectionSubmitted", EntityType = "DailyInspection", EntityId = entity.Id.ToString(), Details = $"Equipment={equipment.Code}; Date={r.InspectionDate}; Shift={r.ShiftCode}; NOK={r.Results.Count(x => x.ResultStatus == "NOK")}" });
        await db.SaveChangesAsync(); await tx.CommitAsync();
        return Created($"/api/inspections/{entity.Id}", new { entity.Id, entity.State, entity.InspectionDate, entity.ShiftCode });
    }
}

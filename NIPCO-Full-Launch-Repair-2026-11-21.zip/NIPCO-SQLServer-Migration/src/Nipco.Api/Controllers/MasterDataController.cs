using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Nipco.Application.Contracts;
using Nipco.Domain.Entities;
using Nipco.Infrastructure.Persistence;

namespace Nipco.Api.Controllers;

[ApiController, Route("api")]
[Authorize]
public sealed class MasterDataController(MaintenanceDbContext db) : ControllerBase
{
    [HttpGet("groups")]
    public async Task<IActionResult> Groups() => Ok(await db.EquipmentGroups.AsNoTracking().OrderBy(x => x.Name).Select(x => new { x.Id, x.Code, x.Name, x.Description, x.IsActive, x.CreatedUtc }).ToListAsync());

    [HttpPost("groups"), Authorize(Policy = "MasterDataWrite")]
    public async Task<IActionResult> CreateGroup(CreateGroupRequest r)
    {
        if (string.IsNullOrWhiteSpace(r.Code) || string.IsNullOrWhiteSpace(r.Name)) return BadRequest(new { message = "کد و نام گروه الزامی است." });
        var entity = new EquipmentGroup { Code = r.Code.Trim(), Name = r.Name.Trim(), Description = r.Description?.Trim() };
        db.EquipmentGroups.Add(entity); await db.SaveChangesAsync(); return Created($"/api/groups/{entity.Id}", entity);
    }

    [HttpGet("equipment")]
    public async Task<IActionResult> Equipment([FromQuery] string? q, [FromQuery] int page = 1, [FromQuery] int pageSize = 50)
    {
        page = Math.Max(1, page); pageSize = Math.Clamp(pageSize, 1, 200);
        var query = db.Equipment.AsNoTracking().Include(x => x.Group).AsQueryable();
        if (!string.IsNullOrWhiteSpace(q)) query = query.Where(x => x.Code.Contains(q) || x.Name.Contains(q) || x.Location.Contains(q));
        var total = await query.CountAsync();
        var items = await query.OrderBy(x => x.Code).Skip((page - 1) * pageSize).Take(pageSize).Select(x => new { x.Id, x.Code, x.Name, x.Type, x.GroupId, x.Site, x.Location, x.QrCode, x.IsActive, x.CreatedUtc }).ToListAsync();
        return Ok(new { total, page, pageSize, items });
    }

    [HttpPost("equipment"), Authorize(Policy = "MasterDataWrite")]
    public async Task<IActionResult> CreateEquipment(CreateEquipmentRequest r)
    {
        if (string.IsNullOrWhiteSpace(r.Code) || string.IsNullOrWhiteSpace(r.Name) || string.IsNullOrWhiteSpace(r.Location)) return BadRequest(new { message = "کد، نام و محل تجهیز الزامی است." });
        if (!await db.EquipmentGroups.AnyAsync(x => x.Id == r.GroupId && x.IsActive)) return BadRequest(new { message = "گروه تجهیز معتبر نیست." });
        var e = new Equipment { Code = r.Code.Trim(), Name = r.Name.Trim(), Type = r.Type.Trim(), GroupId = r.GroupId, Site = r.Site.Trim(), Location = r.Location.Trim(), QrCode = string.IsNullOrWhiteSpace(r.QrCode) ? null : r.QrCode.Trim() };
        db.Equipment.Add(e); await db.SaveChangesAsync(); return Created($"/api/equipment/{e.Id}", e);
    }

    [HttpGet("check-items")]
    public async Task<IActionResult> CheckItems([FromQuery] Guid? groupId)
    {
        var query = db.CheckItems.AsNoTracking().Where(x => x.IsActive);
        if (groupId.HasValue) query = query.Where(x => x.Groups.Any(g => g.EquipmentGroupId == groupId.Value));
        return Ok(await query.OrderBy(x => x.Section).ThenBy(x => x.SortOrder).Select(x => new { x.Id, x.Code, x.Title, x.Section, x.ValueType, x.Unit, x.MinValue, x.MaxValue, x.IsRequired, x.IsActive, x.SortOrder, EquipmentGroupIds = x.Groups.Select(g => g.EquipmentGroupId).ToArray() }).ToListAsync());
    }

    [HttpPost("check-items"), Authorize(Policy = "MasterDataWrite")]
    public async Task<IActionResult> CreateCheckItem(CreateCheckItemRequest r)
    {
        if (string.IsNullOrWhiteSpace(r.Code) || string.IsNullOrWhiteSpace(r.Title)) return BadRequest(new { message = "کد و عنوان آیتم الزامی است." });
        if (r.ValueType is not ("Boolean" or "Numeric" or "Text")) return BadRequest(new { message = "نوع آیتم باید Boolean، Numeric یا Text باشد." });
        if (r.MinValue.HasValue && r.MaxValue.HasValue && r.MinValue > r.MaxValue) return BadRequest(new { message = "حداقل مقدار نمی‌تواند از حداکثر بیشتر باشد." });
        var groups = await db.EquipmentGroups.Where(g => r.EquipmentGroupIds.Contains(g.Id) && g.IsActive).Select(g => g.Id).ToListAsync();
        if (groups.Count != r.EquipmentGroupIds.Distinct().Count()) return BadRequest(new { message = "یک یا چند گروه انتخاب‌شده معتبر نیست." });
        var item = new CheckItem { Code = r.Code.Trim(), Title = r.Title.Trim(), Section = r.Section.Trim(), ValueType = r.ValueType, Unit = r.Unit, MinValue = r.MinValue, MaxValue = r.MaxValue, IsRequired = r.IsRequired, SortOrder = r.SortOrder };
        foreach (var id in groups) item.Groups.Add(new CheckItemGroup { EquipmentGroupId = id });
        db.CheckItems.Add(item); await db.SaveChangesAsync(); return Created($"/api/check-items/{item.Id}", item);
    }
}

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Nipco.Infrastructure.Persistence;

namespace Nipco.Api.Controllers;

[ApiController, Route("api/dashboard"), Authorize]
public sealed class DashboardController(MaintenanceDbContext db) : ControllerBase
{
    [HttpGet("summary")]
    public async Task<IActionResult> Summary([FromQuery] DateOnly? date)
    {
        var day = date ?? DateOnly.FromDateTime(DateTime.Today);
        var totalEquipment = await db.Equipment.CountAsync(x => x.IsActive);
        var inspections = db.DailyInspections.Where(x => x.InspectionDate == day && x.State == "Submitted");
        var completed = await inspections.CountAsync();
        var nok = await inspections.SelectMany(x => x.Results).CountAsync(x => x.ResultStatus == "NOK");
        var equipmentWithInspection = await inspections.Select(x => x.EquipmentId).Distinct().CountAsync();
        return Ok(new { date = day, totalEquipment, completedInspections = completed, equipmentInspected = equipmentWithInspection, equipmentNotInspected = Math.Max(0, totalEquipment - equipmentWithInspection), nokResults = nok });
    }
}

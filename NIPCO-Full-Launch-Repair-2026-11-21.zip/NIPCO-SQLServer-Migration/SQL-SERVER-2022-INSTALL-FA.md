# راهنمای نصب SQL Server 2022 برای NIPCO (فارسی)

## 1) ابتدا Edition مناسب را انتخاب کنید

**نکته سازگاری مهم:** طبق جدول رسمی Microsoft، SQL Server 2022 Enterprise روی Windows 11 پشتیبانی نمی‌شود. SQL Server 2022 Developer و Standard در Windows 11 پشتیبانی می‌شوند. Enterprise روی Windows Server 2022 پشتیبانی می‌شود.

- اگر رایانه فعلی Windows 11 است و فقط می‌خواهید برنامه را نصب و آزمایش کنید: SQL Server 2022 **Developer Edition** را نصب کنید. این نسخه برای توسعه و تست است و مجوز استفاده Production ندارد.
- اگر قرار است محیط واقعی شرکت با SQL Server 2022 **Enterprise** اجرا شود: آن را روی Windows Server 2022 نصب کنید و از رسانه و کلید/مجوز معتبر Enterprise استفاده کنید.
- صرف داشتن فایل ISO یا نام Enterprise به معنی داشتن مجوز معتبر نیست؛ شرایط مجوز سازمان را بررسی کنید.

## 2) آماده‌سازی رسانه نصب

1. فایل ISO رسمی SQL Server 2022 را در Windows باز کنید (Right-click > Mount).
2. وارد درایو مجازی ساخته‌شده شوید.
3. روی `setup.exe` راست‌کلیک کنید و `Run as administrator` را بزنید.
4. در SQL Server Installation Center به بخش `Installation` بروید.
5. `New SQL Server standalone installation or add features to an existing installation` را انتخاب کنید.

## 3) گزینه‌های مهم در Setup

1. **Product Key / Edition:** Edition مجاز و متناسب با سیستم‌عامل را انتخاب کنید. روی Windows 11 برای تست Developer و روی Windows Server 2022 برای Enterprise.
2. **License Terms:** شرایط مجوز را بخوانید و بپذیرید.
3. **Feature Selection:** گزینه `Database Engine Services` را انتخاب کنید. برای این برنامه، Analysis Services و Integration Services لازم نیستند. Full-Text Search اختیاری است.
4. **Instance Configuration:** گزینه `Default instance` را انتخاب کنید. این حالت نام Instance را `MSSQLSERVER` می‌کند و برنامه با `localhost` به آن وصل می‌شود. اگر Default Instance از قبل وجود دارد، می‌توانید Named Instance مانند `NIPCO2022` بسازید؛ در آن صورت نام اتصال `localhost\NIPCO2022` خواهد بود.
5. **Server Configuration:** سرویس `SQL Server Database Engine` را روی `Automatic` قرار دهید. برای نصب محلی، حساب مجازی پیش‌فرض سرویس مناسب است.
6. **Database Engine Configuration > Server Configuration:** برای راه‌اندازی NIPCO، `Windows Authentication Mode` را انتخاب کنید؛ Mixed Mode لازم نیست.
7. در بخش `SQL Server Administrators` حتماً `Add Current User` را بزنید. این کار حساب Windows فعلی را مدیر SQL می‌کند تا نصب‌کننده بتواند دیتابیس NIPCO را ایجاد کند.
8. تنظیمات دیگر را در حالت پیش‌فرض بگذارید، نصب را کامل کنید و در صورت درخواست Setup، ویندوز را Restart کنید.

**مهم:** نصب‌کننده NIPCO و اجرای بعدی برنامه باید با همان حساب Windows انجام شود که در صفحه `Add Current User` به‌عنوان مدیر SQL اضافه شده است. از اجرای Install/Start با حساب‌های Windows متفاوت خودداری کنید، مگر اینکه برای حساب اجرای برنامه جداگانه مجوز SQL تعریف شده باشد.

## 4) نصب SQL Server Management Studio (SSMS)

SSMS ابزار مدیریت دیتابیس است و جدا از Database Engine نصب می‌شود. برای نصب، راهنمای رسمی Microsoft را باز کنید و نصب‌کننده SSMS 22 را دریافت کنید:

https://learn.microsoft.com/en-us/ssms/install/install

پس از نصب SSMS:

- Server type: `Database Engine`
- Server name: `localhost` برای Default Instance یا `localhost\NIPCO2022` برای Named Instance
- Authentication: `Windows Authentication`
- گزینه `Connect` را بزنید.

## 5) بررسی سرویس SQL Server

PowerShell را با Run as administrator باز کنید و اجرا کنید:

```powershell
Get-Service MSSQLSERVER
```

اگر Default Instance نصب شده باشد، وضعیت باید `Running` باشد. برای فهرست سرویس‌های Instanceها:

```powershell
Get-Service | Where-Object { $_.Name -eq 'MSSQLSERVER' -or $_.Name -like 'MSSQL$*' } | Format-Table Name, Status
```

## 6) اتصال NIPCO به SQL Server

بسته NIPCO به‌صورت پیش‌فرض از `localhost` و Windows Authentication استفاده می‌کند.

از PowerShell (با همان حساب Windows که هنگام نصب SQL در `Add Current User` معرفی شد) وارد پوشه پروژه شوید. برای Default Instance:

```powershell
cd C:\NIPCO\It1\NIPCO-SQLServer-Migration
Set-ExecutionPolicy -Scope Process Bypass -Force
.\scripts\Install-NIPCO.ps1
```

برای Named Instance، مثلاً `NIPCO2022`:

```powershell
.\scripts\Install-NIPCO.ps1 -SqlInstance "localhost\NIPCO2022"
```

اسکریپت، نام Instance انتخاب‌شده را در `%ProgramData%\NIPCO\Config\sql-instance.txt` ذخیره می‌کند؛ بنابراین برای اجرای دفعات بعدی کافی است اجرا کنید:

```powershell
.\scripts\Start-NIPCO.ps1
```

برنامه از طریق `https://localhost:7241` در همان رایانه باز می‌شود.

## 7) نکات شبکه‌ای و امنیت

- برای کاربران دیگر شبکه، مرورگر کاربران به API روی سرور وصل می‌شود؛ لازم نیست SQL Server را مستقیماً برای همه کاربران شبکه باز کنید.
- در سناریوی چندکاربره، برنامه و SQL Server را روی میزبان مناسب (ترجیحاً Windows Server) اجرا کنید و برای API گواهی HTTPS سازمانی، حساب سرویس اختصاصی و مجوزهای حداقلی تعریف کنید.
- `TrustServerCertificate=True` در این بسته برای شروع محلی و گواهی توسعه است؛ پیش از بهره‌برداری واقعی باید گواهی معتبر SQL Server پیکربندی و این گزینه `False` شود.
- پیش از ورود اطلاعات واقعی، بکاپ‌گیری منظم از دیتابیس و آزمون بازیابی را طراحی کنید.
